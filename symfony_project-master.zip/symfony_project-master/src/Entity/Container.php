<?php
/**
 * Created by PhpStorm.
 * User: moi
 * Date: 21/12/2018
 * Time: 14:49
 */

namespace App\Entity;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\ContainerRepository")
 * @ORM\Table(name="CONTAINER")
 */

class Container
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */

    private $id;

    /**
     * @ORM\Column(type="string", length=20, name="COLOR")
     */


    private $color;

    /**
     * @ORM\Column(type="integer", name="CONTAINER_MODEL_ID")
     */

    private $containerModelId;

    /**
     * @ORM\Column(type="integer", name="CONTAINERSHIP_ID")
     */

    private $containershipId;

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id): void
    {
        $this->id = $id;
    }

    /**
     * @return mixed
     */
    public function getColor()
    {
        return $this->color;
    }

    /**
     * @param mixed $color
     */
    public function setColor($color): void
    {
        $this->color = $color;
    }

    /**
     * @return mixed
     */
    public function getContainerModelId()
    {
        return $this->containerModelId;
    }

    /**
     * @param mixed $containerModelId
     */
    public function setContainerModelId($containerModelId): void
    {
        $this->containerModelId = $containerModelId;
    }

    /**
     * @return mixed
     */
    public function getContainershipId()
    {
        return $this->containershipId;
    }

    /**
     * @param mixed $containershipId
     */
    public function setContainershipId($containershipId): void
    {
        $this->containershipId = $containershipId;
    }

    public function __toString()
    {
        // TODO: Implement __toString() method.
        return ("ID: ".$this->getId()." color: ".$this->getColor()." ContainerModel: ".$this->getContainerModelId()." ContairnerShipID: ".$this->getContainershipId());
    }


}