<?php
/**
 * Created by PhpStorm.
 * User: moi
 * Date: 21/12/2018
 * Time: 13:55
 */

namespace App\Entity;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\ContainershipRepository")
 * @ORM\Table(name="CONTAINERSHIP")
 */

class Containership
{
    /**
    * @ORM\Id
    * @ORM\GeneratedValue
    * @ORM\Column(type="integer")
    */

    private $id;

    /**
     * @ORM\Column(type="string", length=255, name="NAME")
     */


    private $name;

    /**
     * @ORM\Column(type="string", length=255, name="CAPTAIN_NAME")
     */

    private $captainName;

    /**
     * @ORM\Column(type="integer", name="CONTAINER_LIMIT")
     */

    private $containerLimit;




    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id): void
    {
        $this->id = $id;
    }

    /**
     * @return mixed
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @param mixed $name
     */
    public function setName($name): void
    {
        $this->name = $name;
    }

    /**
     * @return mixed
     */
    public function getCaptainName()
    {
        return $this->captainName;
    }

    /**
     * @param mixed $captainName
     */
    public function setCaptainName($captainName): void
    {
        $this->captainName = $captainName;
    }

    /**
     * @return mixed
     */
    public function getContainerLimit()
    {
        return $this->containerLimit;
    }

    /**
     * @param mixed $containerLimit
     */
    public function setContainerLimit($containerLimit): void
    {
        $this->containerLimit = $containerLimit;
    }

    public function __toString()
    {
        return ("ID: ".$this->getId()." name: ".$this->getName()." Captain name: ".$this->getCaptainName()." container limit: ".$this->getContainerLimit());
    }


}