<?php
/**
 * Created by PhpStorm.
 * User: moi
 * Date: 21/12/2018
 * Time: 15:03
 */

namespace App\Entity;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\ProductRepository")
 * @ORM\Table(name="PRODUCT")
 */

class Product
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */

    private $id;

    /**
     * @ORM\Column(type="string", length=255, name="NAME")
     */


    private $name;

    /**
     * @ORM\Column(type="integer", name="LENGTH")
     */

    private $length;

    /**
     * @ORM\Column(type="integer", name="WIDTH")
     */

    private $width;

    /**
     * @ORM\Column(type="integer", name="HEIGHT")
     */

    private $height;

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id): void
    {
        $this->id = $id;
    }

    /**
     * @return mixed
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @param mixed $name
     */
    public function setName($name): void
    {
        $this->name = $name;
    }

    /**
     * @return mixed
     */
    public function getLength()
    {
        return $this->length;
    }

    /**
     * @param mixed $length
     */
    public function setLength($length): void
    {
        $this->length = $length;
    }

    /**
     * @return mixed
     */
    public function getWidth()
    {
        return $this->width;
    }

    /**
     * @param mixed $width
     */
    public function setWidth($width): void
    {
        $this->width = $width;
    }

    /**
     * @return mixed
     */
    public function getHeight()
    {
        return $this->height;
    }

    /**
     * @param mixed $height
     */
    public function setHeight($height): void
    {
        $this->height = $height;
    }

    public function __toString()
    {
        // TODO: Implement __toString() method.
        return ("ID: ".$this->getId()."Length: ".$this->getLength()." Width: ".$this->getWidth()." height: ".$this->getHeight());
    }

}