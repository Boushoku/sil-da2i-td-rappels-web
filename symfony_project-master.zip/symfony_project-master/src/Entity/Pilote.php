<?php
/**
 * Created by PhpStorm.
 * User: moi
 * Date: 19/12/2018
 * Time: 09:37
 */

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\PiloteRepository")
 * @ORM\Table(name="PILOTE")
 */


class Pilote
{

    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */

    private $id;

     /**
     * @ORM\Column(type="string", length=255)
     */


    private $NOM;

    /**
     * @ORM\Column(type="string", length=1, name="EN_ACTIVITE")
     */

    private $EN_ACTIVE;


    public function getId(){
        return $this->id;
    }

    public function getName(){
        return $this->NOM;
    }

    public function isActive(){
        return $this->EN_ACTIVE;
    }


    public function setId($a){
        return $this->id = $a;
    }

    public function setName($a){
        return $this->NOM = $a;
    }

    public function setActive($a){
        return $this->EN_ACTIVE = $a;
    }




}