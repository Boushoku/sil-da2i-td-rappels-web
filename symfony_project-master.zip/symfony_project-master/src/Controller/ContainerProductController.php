<?php
/**
 * Created by PhpStorm.
 * User: moi
 * Date: 21/12/2018
 * Time: 15:16
 */

namespace App\Controller;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use App\Entity\ContainerProduct;


class ContainerProductController extends AbstractController
{
    /**
     * @Route("/ContainerProduct", name="ContainerProduct")
     */
    public function index()
    {
        // you can fetch the EntityManager via $this->getDoctrine()
        // or you can add an argument to your action: index(EntityManagerInterface $entityManager)
        $entityManager = $this->getDoctrine()->getManager();

        $ContainerProduct = new ContainerProduct();

        $ContainerProduct->setContainerId(3);
        $ContainerProduct->setProductId(1);
        $ContainerProduct->setQuantity(10);

        // tell Doctrine you want to (eventually) save the Product (no queries yet)
        $entityManager->persist($ContainerProduct);

        // actually executes the queries (i.e. the INSERT query)
        $entityManager->flush();

        return new Response('Saved new product with id '.$ContainerProduct->getId());
    }

    /**
     * @Route("/ContainerProduct/{id}", name="ContainerProduct_show")
     */
    public function show($id)
    {
        $ContainerProduct = $this->getDoctrine()
            ->getRepository(ContainerProduct::class)
            ->find($id);

        if (!$ContainerProduct) {
            throw $this->createNotFoundException(
                'No product found for id '.$id
            );
        }

        return new Response('Check out this great product: '.$ContainerProduct->getName());

    }
}