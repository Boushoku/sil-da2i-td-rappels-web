<?php
/**
 * Created by PhpStorm.
 * User: moi
 * Date: 21/12/2018
 * Time: 14:39
 */

namespace App\Controller;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use App\Entity\ContainerModel;

class ContainerModelController extends AbstractController
{
    /**
     * @Route("/ContainerModel", name="ContainerModel")
     */
    public function index()
    {
        // you can fetch the EntityManager via $this->getDoctrine()
        // or you can add an argument to your action: index(EntityManagerInterface $entityManager)
        $entityManager = $this->getDoctrine()->getManager();

        $ContainerModel = new ContainerModel();
        $ContainerModel->setName('Richard');

        // tell Doctrine you want to (eventually) save the Product (no queries yet)
        $entityManager->persist($ContainerModel);

        // actually executes the queries (i.e. the INSERT query)
        $entityManager->flush();

        return new Response('Saved new product with id '.$ContainerModel->getId());
    }

    /**
     * @Route("/ContainerModel/{id}", name="ContainerModel_show")
     */
    public function show($id)
    {
        $ContainerModel = $this->getDoctrine()
            ->getRepository(ContainerModel::class)
            ->find($id);

        if (!$ContainerModel) {
            throw $this->createNotFoundException(
                'No product found for id '.$id
            );
        }

        return new Response('Check out this great product: '.$ContainerModel->getName());

    }
}