<?php
/**
 * Created by PhpStorm.
 * User: moi
 * Date: 19/12/2018
 * Time: 09:58
 */

// src/Controller/ProductController.php

namespace App\Controller;

// ...

use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use App\Entity\Pilote;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class PiloteController extends AbstractController
{
    /**
     * @Route("/Pilote", name="pilote")
     */
    public function index()
    {
        // you can fetch the EntityManager via $this->getDoctrine()
        // or you can add an argument to your action: index(EntityManagerInterface $entityManager)
        $entityManager = $this->getDoctrine()->getManager();

        $pilote = new Pilote();
        $pilote->setName('Richard');
        $pilote->setActive('0');

        // tell Doctrine you want to (eventually) save the Product (no queries yet)
        $entityManager->persist($pilote);

        // actually executes the queries (i.e. the INSERT query)
        $entityManager->flush();

        return new Response('Saved new product with id '.$pilote->getId());
    }

    /**
     * @Route("/Pilote/{id}", name="pilote_show")
     */
    public function show($id)
    {
        $pilote = $this->getDoctrine()
            ->getRepository(Pilote::class)
            ->find($id);

        if (!$pilote) {
            throw $this->createNotFoundException(
                'No product found for id '.$id
            );
        }

        return new Response('Check out this great product: '.$pilote->getName());

    }
}