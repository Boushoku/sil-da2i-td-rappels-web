<?php
/**
 * Created by PhpStorm.
 * User: moi
 * Date: 21/12/2018
 * Time: 14:07
 */

namespace App\Controller;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use App\Entity\Containership;

class ContainershipController extends AbstractController
{
    /**
     * @Route("/Containership", name="Containership")
     */
    public function index()
    {
        // you can fetch the EntityManager via $this->getDoctrine()
        // or you can add an argument to your action: index(EntityManagerInterface $entityManager)
        $entityManager = $this->getDoctrine()->getRepository(Containership::class)->findAll();

        return $this->render('lucky/containership.html.twig', ['containerships' => $entityManager]);
    }

    /**
     * @Route("/Containership/{id}", name="Containership_show")
     */
    public function show($id)
    {
        $Containership = $this->getDoctrine()
            ->getRepository(Containership::class)
            ->find($id);

        if (!$Containership) {
            throw $this->createNotFoundException(
                'No product found for id '.$id
            );
        }

        return new Response('Check out this great containership: '.$Containership);

    }
}