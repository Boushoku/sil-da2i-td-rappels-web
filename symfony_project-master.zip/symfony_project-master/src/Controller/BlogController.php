<?php
// src/Controller/BlogController.php
namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

class BlogController extends AbstractController
{
    public function list()
    {
        // ...
        $number = random_int(100, 200);

        return $this->render('lucky/number.html.twig', ['number' => $number,]);
    }

    public function show($slug)
    {
        // $slug will equal the dynamic part of the URL
        // e.g. at /blog/yay-routing, then $slug='yay-routing'

        // ...
        $number = random_int(200, 300);

        return $this->render('lucky/number.html.twig', ['number' => $number,]);
    }
}
