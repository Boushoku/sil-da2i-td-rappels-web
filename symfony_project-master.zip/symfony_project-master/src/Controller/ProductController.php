<?php
/**
 * Created by PhpStorm.
 * User: moi
 * Date: 21/12/2018
 * Time: 15:07
 */

namespace App\Controller;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use App\Entity\Product;


class ProductController extends AbstractController
{
    /**
     * @Route("/Product", name="Product")
     */
    public function index()
    {
        // you can fetch the EntityManager via $this->getDoctrine()
        // or you can add an argument to your action: index(EntityManagerInterface $entityManager)
        $entityManager = $this->getDoctrine()->getRepository(Product::class)->findAll();

        return $this->render('lucky/product.html.twig', ['products' => $entityManager]);
    }

    /**
     * @Route("/Product/{id}", name="Product_show")
     */
    public function show($id)
    {
        $Product = $this->getDoctrine()
            ->getRepository(Product::class)
            ->find($id);

        if (!$Product) {
            throw $this->createNotFoundException(
                'No product found for id '.$id
            );
        }

        return new Response('Check out this great product: '.$Product);

    }
}