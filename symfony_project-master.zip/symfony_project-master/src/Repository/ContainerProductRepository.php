<?php
/**
 * Created by PhpStorm.
 * User: moi
 * Date: 21/12/2018
 * Time: 15:15
 */

namespace App\Repository;
use App\Entity\ContainerProduct;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Symfony\Bridge\Doctrine\RegistryInterface;


class ContainerProductRepository extends ServiceEntityRepository
{
    public function __construct(RegistryInterface $registry)
    {
        parent::__construct($registry, ContainerProduct::class);
    }
}