<?php
/**
 * Created by PhpStorm.
 * User: moi
 * Date: 21/12/2018
 * Time: 14:54
 */

namespace App\Repository;
use App\Entity\Container;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Symfony\Bridge\Doctrine\RegistryInterface;


class ContainerRepository extends ServiceEntityRepository
{
    public function __construct(RegistryInterface $registry)
    {
        parent::__construct($registry, Container::class);
    }
}