<?php
/**
 * Created by PhpStorm.
 * User: moi
 * Date: 19/12/2018
 * Time: 10:07
 */

namespace App\Repository;
use App\Entity\Pilote;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Symfony\Bridge\Doctrine\RegistryInterface;


class PiloteRepository extends ServiceEntityRepository
{
    public function __construct(RegistryInterface $registry)
    {
        parent::__construct($registry, Pilote::class);
    }
}