<body>
<div class "content">
<header class="header"><font color="black">Stanley Kubrick</font></header>
<article class="main">
    <p> Prénom : Stanley</p>
    <p> Nom : Kubrick</p>
    <p> Date de naissance : <time datetime="1928-26-08">26 juillet 1928</time></p>
    <p>biographie :Malcolm McDowell grandit à Bridlington, dans le Yorkshire, puis déménage à Liverpool où il est fan des Reds du Liverpool FC qu'il supporte dans le kop. Son père travaillait pour la Royal Air Force.

        Sa formation de comédien a lieu à la London Academy of Music and Dramatic Art.

        Il commence en jouant dans Pas de larmes pour Joy, mais les deux minutes où il apparaît ne sont pas retenues au montage final. Lindsay Anderson le remarque lors d'un casting et lui propose l'un des rôles principaux de If..., film qui obtiendra la Palme d'or au festival de Cannes 1969.

        C'est en voyant ce film que Stanley Kubrick pense à lui donner le rôle principal de son long-métrage Orange mécanique, qui lui vaudra une nomination au Golden Globe du meilleur acteur dans un film dramatique.

        Sa capacité à jouer des personnages inquiétants lui vaut d'incarner le terrible empereur Caligula dans le film du même nom de Tinto Brass en 1979.

        Il tourne ensuite encore avec Lindsay Anderson dans les suites de If..., Le Meilleur des mondes possible et Britannia Hospital.

        Il joue H.G. Wells dans le film de science-fiction C'était demain.

        Pour le remake du film culte de John Carpenter Halloween, il incarne le docteur Loomis dans les films Halloween (2007) et Halloween 2 (2009).

        Malcolm McDowell vit actuellement à Ojai en Californie.</p>
</article>
</div>
</body>
