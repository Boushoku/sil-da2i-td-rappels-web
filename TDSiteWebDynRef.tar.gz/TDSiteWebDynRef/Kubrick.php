<!doctype html>
<html lang="fr">
<?php
  require("config.php")
?>

<?php getBlock("menu.php")?>
<body>
<div class "content">
<header class="header"><font color="black">Stanley Kubrick</font></header>
<article class="main">

    <?php
    getBlock("infosKubrick.php");
    ?>
    <?php
    getBlock("filmoKubrick.php");
    ?>
</article>

</div>
</body>
</html>