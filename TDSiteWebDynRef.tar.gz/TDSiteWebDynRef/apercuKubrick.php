
<a href="Kubrick.php">
<figure class ="real" >
    <img class="kubrick"
         src="images/KubrickForLook.jpg"
         alt="Orange Mecanique promo poster"/>
    <figcaption class = "caption_stanley">Stanley Kubrick</figcaption>
</figure></a>