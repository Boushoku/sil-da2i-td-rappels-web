<!doctype html>
<html lang="fr">
<footer class="footer">
    Thibaut Chevallier
</footer>