<!doctype html>
<html lang="fr">
    <?php
      require("config.php")
    ?>
    <?php
      getBlock("menu.php");
    ?>
    <?php getBlock("apercuKubrick.php")?>
</html>
