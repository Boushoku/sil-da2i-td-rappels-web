<!doctype html>
<html lang="fr">
<link type="text/css" rel='stylesheet' href="index.css">
<?php
  require ("config.php");
  getBlock("head.php");
 ?>
<body>
    <?php
        require("menu.php");
    ?>
  <div class="wrapper">
    <header class="header"><font color="orange">Orange</font><font color="white">Mecanique</font></header>
      <?php
        require("infos.php");
      ?>
    <aside class="aside aside-1">Fiches techniques
      <ol>
          <li><a href="actor.php">Actors</a></li>
          <li><a href="director.php">Director</a></li>
      </ol>
    </aside>
    <aside class="aside aside-2">
      <figure class = ptn>
      <img class="fit-picture"
       src="images/Clockwork_Orange_Trailer_poster.png"
       alt="Orange Mecanique promo poster"/>
       <figcaption>Affiche de Orange Mecanique</figcaption>
      </figure>
     </aside>
      <?php
        require("listImage.php");
      ?>
     <article class="actorAndreal">
      <?php
         require("apercuKubrick.php");
      ?>
      <?php
        getBlock("apercuMcDowell.php");
      ?>
   </article>
      <?php
        require("footer.php");
      ?>
  </div>

</body>
</html>
