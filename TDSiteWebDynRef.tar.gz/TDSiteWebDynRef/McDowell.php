<!doctype html>
<html lang="fr">

<?php require("config.php")?>

 <?php getBlock("menu.php")?>
 <?php getBlock("apercuMcDowell.php")?>
 <?php getBlock("infosMcDowell.php") ?>

</html>