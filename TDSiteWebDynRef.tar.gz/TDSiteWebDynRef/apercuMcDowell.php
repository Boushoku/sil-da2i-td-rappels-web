<a href="McDowell.php">
    <figure class ="actor">
        <img class="mcdowell"
             src="images/mcdowell.jpg"
             alt="Orange Mecanique promo poster"/>
        <figcaption class = "caption_malcolm">Malcolm McDowell</figcaption>
    </figure>
    </figure></a>