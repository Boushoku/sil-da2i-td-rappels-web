<head>
  <meta charset="utf-8">
  <link rel="shortcut icon" type="image/png" href="images/IconOrangemecanique.png" />
	<title>Orange Mecanique - The Site </title>
</head>
