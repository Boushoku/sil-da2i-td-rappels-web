
<head>
    <meta charset="utf-8">
    <link rel="shortcut icon" type="image/png" href="images/IconOrangemecanique.png" />
    <title>Stanley Kubrick</title>
    <link type="text/css" rel='stylesheet' href="director.css">
</head>

    <img class="Stan"
         src="images/KubrickForLook.jpg"/>
    <p> Prénom : Stanley</p>
    <p> Nom : Kubrick</p>
    <p> Date de naissance : <time datetime="1928-26-08">26 juillet 1928</time></p>
    <p>biographie : Stanley Kubrick est un réalisateur, photographe, scénariste et producteur américain né le 26 juillet 1928 dans la ville de New York à Manhattan1,2, et mort le 7 mars 1999 dans son manoir de Childwickbury, entre St Albans et Harpenden (Hertfordshire, nord de Londres). <br> Après des débuts dans la photographie, Kubrick, autodidacte, sera également son propre directeur de la photographie, producteur, scénariste ou encore monteur. Ses treize longs métrages en quarante-six ans de carrière l'imposent comme l'un des cinéastes majeurs du xxe siècle. Quatre de ses films sont classés dans le Top 100 de l'American Film Institute.</p>