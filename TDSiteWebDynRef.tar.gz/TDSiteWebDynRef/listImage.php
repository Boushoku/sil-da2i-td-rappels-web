
<article class="picture-movie">
    <div id = "imagesdufilm">
        <img class="AlexDelarge"
             src="images/famous.png"
             alt="Orange Mecanique promo poster"/>
        <img class="fourguys"
             src="images/4guys.jpg"
             alt="Orange Mecanique promo poster"/>
        <img class="prota-action"
             src="images/protaInAction.jpg"
             alt="Orange Mecanique promo poster"/>
    </div>
</article>