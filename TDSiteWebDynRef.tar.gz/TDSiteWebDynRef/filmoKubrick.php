
<p>filmographie
<ol>
    <li>2009
        <ul>
            <li>Spartacus</li>
        </ul>
    </li>
    <li>1999
        <ul>
            <li>Eyes Wide Shut</li>
        </ul>
    </li>
    <li>1987
        <ul>
            <li>Full Metal Jacket</li>
        </ul>
    </li>
    <li>1980
        <ul>
            <li>Shining</li>
        </ul>
    </li>
    <li>1976
        <ul>
            <li>Barry Lyndon</li>
        </ul>
    </li>
    <li>1971
        <ul>
            <li>Orange Mécanique</li>
        </ul>
    </li>
    <li>1968
        <ul>
            <li>2001, l'odysée de l'espace</li>
        </ul>
    </li>
    <li>1964
        <ul>
            <li>Docteur Folamour</li>
        </ul>
    </li>
    <li>1962
        <ul>
            <li>Lolita</li>
        </ul>
    </li>
    <li>1960
        <ul>
            <li>Spartacus</li>
        </ul>
    </li>
    <li>1957
        <ul>
            <li>Les Sentiers de la gloire</li>
        </ul>
    </li>
    <li>1954
        <ul>
            <li>Le Baiser du tueur</li>
            <li>Fear and Desire</li>
        </ul>
    </li>
    <li>1957
        <ul>
            <li>Les Sentiers de la gloire</li>
        </ul>
    </li>
    <li>1951
        <ul>
            <li>Day of the Fight</li>
            <li>Flying Padre</li>
            <li>The Seafarers</li>
        </ul>

</ol>
