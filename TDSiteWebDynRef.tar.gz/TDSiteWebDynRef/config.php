<?php

$link = mysqli_connect('localhost', 'edward', 'loloes15')
or die('Erreur de connexion au serveur : ' . mysqli_connect_error());
mysqli_select_db($link, 'edward_bd_orangemecanique')
or die ('Erreur de sélection de la BD : ' . mysqli_error($link));
mysqli_set_charset($link, 'utf8');

function getBlock($file, $data = [])
{
    require $file;
}