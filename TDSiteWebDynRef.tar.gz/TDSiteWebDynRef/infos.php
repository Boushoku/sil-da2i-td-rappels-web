
<article class="main">
    <h1>Pitch</h1>
    <p>Dans une Angleterre futuriste et inhumaine, un groupe d'adolescents se déchaînent chaque nuit, frappant et violant d'innocentes victimes. Alex, le leader du gang est arrêté et condamné à 14 ans de prison. Il accepte de se soumettre à une thérapie de choc destinée à faire reculer la criminalité.</p>
    <p>Date de sortie : <time datetime="1971-01-04">Avril 1971</time></p>
    <p>Acteurs principaux : Malcolm McDowell, Patrick Magee, Adrienne Corri, Miriam Karlin</p>
    <div>
        <label for="note">note : 4.5/5</label>
        <meter id="note" name="note" min="0" max="5" value="4">
        </meter>
    </div>
</article>