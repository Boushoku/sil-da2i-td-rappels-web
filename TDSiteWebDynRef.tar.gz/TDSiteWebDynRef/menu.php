<link type="text/css" rel='stylesheet' href="menu.css">
<ul class="navigation">
    <li><a href="index.php">Home</a></li>
    <li><a href="actor.php">Actors</a></li>
    <li><a href="director.php">Directors</a></li>
    <li><a href="#">Contact</a></li>
</ul>

